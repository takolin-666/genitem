<?php
/**
 * Plugin Name: Genitem Connexion
 * Description: Trois retouches aux écrans de connexion de WordPress : le menu de langue est retiré, le courriel tient lieu d'identifiant, et le logo du site remplace celui de WordPress.
 * Version: 1.0.0
 * Author: Genitem
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Adresse du logo. Une seule ligne a changer si le fichier bouge. */
if ( ! defined( 'GNT_CX_LOGO' ) ) {
	define( 'GNT_CX_LOGO', 'https://genitem.recherche-formation.com/wp-content/uploads/2026/09/genitem.svg' );
}


/* 1. Le menu de langue ------------------------------------------------ */

add_filter( 'login_display_language_dropdown', '__return_false' );


/* 2. Le courriel tient lieu d'identifiant ----------------------------- */

if ( ! function_exists( 'gnt_cx_identifiant' ) ) {
	/**
	 * Avant que WordPress ne traite l'envoi, l'adresse est recopiee dans
	 * le champ identifiant. WordPress accepte l'arobase : rien d'autre a
	 * forcer.
	 */
	function gnt_cx_identifiant() {
		if ( empty( $_POST['user_email'] ) ) {
			return;
		}
		$_POST['user_login'] = sanitize_user( wp_unslash( $_POST['user_email'] ), true );
	}
}
add_action( 'login_form_register', 'gnt_cx_identifiant' );

if ( ! function_exists( 'gnt_cx_masquer' ) ) {
	/**
	 * Le champ identifiant est masque et libere de son attribut required :
	 * un champ obligatoire et invisible bloquerait l'envoi, le navigateur
	 * refusant de signaler une erreur sur ce qu'il ne montre pas.
	 */
	function gnt_cx_masquer() {
		$action = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : '';
		if ( 'register' !== $action ) {
			return;
		}
		?>
		<script>
		document.addEventListener('DOMContentLoaded', function () {
			var champ = document.getElementById('user_login');
			if (!champ) { return; }
			champ.removeAttribute('required');
			var bloc = champ.closest('p');
			if (bloc) { bloc.style.display = 'none'; }
			var courriel = document.getElementById('user_email');
			if (courriel) { courriel.focus(); }
		});
		</script>
		<?php
	}
}
add_action( 'login_footer', 'gnt_cx_masquer' );

if ( ! function_exists( 'gnt_cx_nom_affiche' ) ) {
	/**
	 * Filet de securite. Par defaut, WordPress tire le nom affiche de
	 * l'identifiant : avec l'adresse pour identifiant, chaque message du
	 * forum porterait le courriel de son auteur, en clair. On ne garde
	 * que ce qui precede l'arobase.
	 *
	 * @param int $id Identifiant numerique du compte cree.
	 */
	function gnt_cx_nom_affiche( $id ) {
		$compte = get_userdata( $id );
		if ( ! $compte || empty( $compte->user_email ) ) {
			return;
		}

		$parts = explode( '@', $compte->user_email );
		$base  = sanitize_title( $parts[0] );
		if ( '' === $base ) {
			$base = 'membre';
		}

		wp_update_user( array(
			'ID'           => $id,
			'nickname'     => $base,
			'display_name' => $base,
		) );
	}
}
add_action( 'user_register', 'gnt_cx_nom_affiche', 20 );


/* 3. Le logo ---------------------------------------------------------- */

if ( ! function_exists( 'gnt_cx_logo' ) ) {
	/**
	 * WordPress plante son propre logo en haut de ces ecrans. On y met
	 * celui du site.
	 */
	function gnt_cx_logo() {
		?>
		<style>
			#login h1 a, .login h1 a {
				background-image: url('<?php echo esc_url( GNT_CX_LOGO ); ?>');
				background-size: contain;
				background-position: center center;
				background-repeat: no-repeat;
				width: 240px;
				height: 62px;
				margin-bottom: 18px;
			}
		</style>
		<?php
	}
}
add_action( 'login_head', 'gnt_cx_logo' );

if ( ! function_exists( 'gnt_cx_logo_lien' ) ) {
	/**
	 * Le logo ramene au site, non a wordpress.org.
	 *
	 * @return string
	 */
	function gnt_cx_logo_lien() {
		return home_url( '/' );
	}
}
add_filter( 'login_headerurl', 'gnt_cx_logo_lien' );

if ( ! function_exists( 'gnt_cx_logo_titre' ) ) {
	/**
	 * L'infobulle porte le nom du site.
	 *
	 * @return string
	 */
	function gnt_cx_logo_titre() {
		return get_bloginfo( 'name', 'display' );
	}
}
add_filter( 'login_headertext', 'gnt_cx_logo_titre' );
