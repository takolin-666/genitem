<?php
/**
 * Plugin Name: Genitem Code de cours
 * Description: Demande un code à l'inscription, réservant la création de compte aux participants d'un cours. Le code se règle sous Réglages puis Général ; laissé vide, il ferme les inscriptions. Indépendant de Genitem Connexion : l'un peut vivre sans l'autre.
 * Version: 1.0.0
 * Author: Genitem
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Aucun code par defaut : a l'activation, les inscriptions sont fermees
   jusqu'a ce qu'un code soit inscrit dans Reglages puis General. */

if ( ! function_exists( 'gnt_code_attendu' ) ) {
	/**
	 * Le code attendu. Vide, les inscriptions sont fermees.
	 *
	 * @return string
	 */
	function gnt_code_attendu() {
		return trim( (string) get_option( 'gnt_code_cours', '' ) );
	}
}

if ( ! function_exists( 'gnt_code_champ' ) ) {
	/**
	 * Le champ, sous l'adresse. Sa valeur revient en cas d'erreur, pour
	 * ne pas faire tout retaper.
	 */
	function gnt_code_champ() {
		$saisi = isset( $_POST['gnt_code'] ) ? sanitize_text_field( wp_unslash( $_POST['gnt_code'] ) ) : '';
		?>
		<p>
			<label for="gnt_code">
				Code du cours <span style="opacity:.6">| Course code</span><br>
				<input type="text" name="gnt_code" id="gnt_code" class="input"
				       value="<?php echo esc_attr( $saisi ); ?>" size="20"
				       autocomplete="off" spellcheck="false">
			</label>
		</p>
		<p style="font-size:12px; color:#50575e; margin:-10px 0 16px;">
			Il vous est donné pendant la séance.
			<span style="opacity:.6">Given to you during the lesson.</span>
		</p>
		<?php
	}
}
add_action( 'register_form', 'gnt_code_champ' );

if ( ! function_exists( 'gnt_code_verifier' ) ) {
	/**
	 * La verification, avant toute creation de compte. La comparaison
	 * ignore la casse et les espaces de bord : un code recopie a la main
	 * n'a pas a etre parfait.
	 *
	 * @param WP_Error $erreurs  Erreurs deja relevees.
	 * @param string   $login    Identifiant propose.
	 * @param string   $courriel Adresse proposee.
	 * @return WP_Error
	 */
	function gnt_code_verifier( $erreurs, $login = '', $courriel = '' ) {
		$attendu = gnt_code_attendu();

		// Pas de code enregistre : aucune inscription ne passe.
		if ( '' === $attendu ) {
			$erreurs->add( 'gnt_code_ferme', '<strong>Erreur</strong> : les inscriptions sont fermées. | Registration is closed.' );
			return $erreurs;
		}

		$saisi = isset( $_POST['gnt_code'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['gnt_code'] ) ) ) : '';

		if ( '' === $saisi ) {
			$erreurs->add( 'gnt_code_absent', '<strong>Erreur</strong> : le code du cours est demandé. | The course code is required.' );
		} elseif ( 0 !== strcasecmp( $saisi, $attendu ) ) {
			$erreurs->add( 'gnt_code_faux', '<strong>Erreur</strong> : ce code ne correspond pas. | This code does not match.' );
		}

		return $erreurs;
	}
}
add_filter( 'registration_errors', 'gnt_code_verifier', 10, 3 );

if ( ! function_exists( 'gnt_code_reglage' ) ) {
	/**
	 * Le reglage, sous Reglages puis General : il change a chaque cours,
	 * mieux vaut un champ qu'un fichier a rouvrir.
	 */
	function gnt_code_reglage() {
		register_setting( 'general', 'gnt_code_cours', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		) );
		add_settings_field( 'gnt_code_cours', 'Code du cours (inscription)', 'gnt_code_reglage_champ', 'general' );
	}
}
add_action( 'admin_init', 'gnt_code_reglage' );

if ( ! function_exists( 'gnt_code_reglage_champ' ) ) {
	/**
	 * L'affichage du reglage.
	 */
	function gnt_code_reglage_champ() {
		$code = gnt_code_attendu();
		?>
		<input type="text" name="gnt_code_cours" id="gnt_code_cours" class="regular-text"
		       value="<?php echo esc_attr( $code ); ?>" autocomplete="off" spellcheck="false">
		<p class="description">
			Demandé sur le formulaire d'inscription. À changer à chaque cours.
			<?php if ( '' === $code ) : ?>
				<br><strong>Vide&nbsp;: les inscriptions sont fermées. Aucun compte ne peut être créé.</strong>
			<?php endif; ?>
		</p>
		<?php
	}
}
