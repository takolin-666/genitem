<?php
/**
 * Plugin Name:       Genitem Models
 * Plugin URI:        https://genitem.recherche-formation.com/
 * Description:       Mémorise, pour chaque utilisateur connecté, la liste des modèles Ollama qu'il a installés. Les pages Genitem (chargées depuis /wp-content/uploads/code/) lisent et écrivent cette liste, de sorte qu'un utilisateur retrouve ses modèles à chaque connexion, sans avoir à télécharger une page modifiée.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Genitem
 * License:           GPL-2.0-or-later
 * Text Domain:       genitem-models
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Pas d'acces direct.
}

define( 'GENITEM_MODELS_VERSION', '1.0.0' );
define( 'GENITEM_MODELS_META_KEY', 'genitem_modeles' );
define( 'GENITEM_MODELS_MAX', 40 );

/**
 * Liste servie aux utilisateurs qui n'ont encore rien enregistre.
 */
function genitem_models_defaut() {
	return array( 'qwen3.5:0.8b' );
}

/**
 * Nettoie un nom de modele : retire un eventuel prefixe "ollama run/pull",
 * les espaces superflus et tout caractere hors du jeu attendu.
 * Renvoie une chaine vide si le nom n'est pas exploitable.
 */
function genitem_models_nettoyer( $nom ) {
	$nom = is_string( $nom ) ? trim( $nom ) : '';
	$nom = preg_replace( '/^ollama\s+(run|pull)\s+/i', '', $nom );
	$nom = trim( $nom );

	// Un nom de modele Ollama : lettres, chiffres, . _ - : / et rien d'autre.
	if ( ! preg_match( '#^[A-Za-z0-9._:/-]{1,100}$#', $nom ) ) {
		return '';
	}
	return $nom;
}

/**
 * Liste enregistree pour un utilisateur, ou la liste par defaut.
 */
function genitem_models_lire( $user_id ) {
	$liste = get_user_meta( $user_id, GENITEM_MODELS_META_KEY, true );

	if ( ! is_array( $liste ) || empty( $liste ) ) {
		return genitem_models_defaut();
	}

	$propre = array();
	foreach ( $liste as $nom ) {
		$nom = genitem_models_nettoyer( $nom );
		if ( '' !== $nom && ! in_array( $nom, $propre, true ) ) {
			$propre[] = $nom;
		}
	}

	return empty( $propre ) ? genitem_models_defaut() : $propre;
}

/**
 * Enregistre la liste d'un utilisateur, apres nettoyage et dedoublonnage.
 */
function genitem_models_ecrire( $user_id, $liste ) {
	if ( ! is_array( $liste ) ) {
		return new WP_Error( 'genitem_format', __( 'Format de liste invalide.', 'genitem-models' ), array( 'status' => 400 ) );
	}

	$propre = array();
	foreach ( $liste as $nom ) {
		$nom = genitem_models_nettoyer( $nom );
		if ( '' !== $nom && ! in_array( $nom, $propre, true ) ) {
			$propre[] = $nom;
		}
		if ( count( $propre ) >= GENITEM_MODELS_MAX ) {
			break;
		}
	}

	if ( empty( $propre ) ) {
		return new WP_Error(
			'genitem_vide',
			__( 'La liste doit contenir au moins un modèle valide.', 'genitem-models' ),
			array( 'status' => 400 )
		);
	}

	update_user_meta( $user_id, GENITEM_MODELS_META_KEY, $propre );
	return $propre;
}

/* -------------------------------------------------------------------------
 * Routes REST
 * ---------------------------------------------------------------------- */

add_action( 'rest_api_init', 'genitem_models_enregistrer_routes' );

function genitem_models_enregistrer_routes() {

	// Etat de connexion : lisible par tous, sans jeton. Ne revele que le nom
	// affiche de l'utilisateur courant, rien d'autre.
	register_rest_route(
		'genitem/v1',
		'/moi',
		array(
			'methods'             => 'GET',
			'callback'            => 'genitem_models_route_moi',
			'permission_callback' => '__return_true',
		)
	);

	// Jeton frais, calcule a chaque appel. Indispensable si la page qui porte
	// le cadre est mise en cache : le jeton inscrit dans le HTML appartiendrait
	// alors a une autre session, et toute ecriture serait refusee.
	register_rest_route(
		'genitem/v1',
		'/jeton',
		array(
			'methods'             => 'GET',
			'callback'            => 'genitem_models_route_jeton',
			'permission_callback' => '__return_true',
		)
	);

	// Lecture de la liste de l'utilisateur connecte.
	register_rest_route(
		'genitem/v1',
		'/modeles',
		array(
			'methods'             => 'GET',
			'callback'            => 'genitem_models_route_lire',
			'permission_callback' => 'genitem_models_utilisateur_connecte',
		)
	);

	// Ecriture : remplace toute la liste.
	register_rest_route(
		'genitem/v1',
		'/modeles',
		array(
			'methods'             => 'POST',
			'callback'            => 'genitem_models_route_ecrire',
			'permission_callback' => 'genitem_models_utilisateur_connecte',
		)
	);
}

function genitem_models_utilisateur_connecte() {
	if ( is_user_logged_in() ) {
		return true;
	}
	return new WP_Error(
		'genitem_non_connecte',
		__( 'Vous devez être connecté pour gérer vos modèles.', 'genitem-models' ),
		array( 'status' => 401 )
	);
}

function genitem_models_route_jeton() {
	// Jamais de mise en cache : la reponse depend de la session en cours.
	nocache_headers();

	// Sur une route REST, WordPress n'identifie l'utilisateur a partir de ses
	// cookies que si un jeton valide accompagne la requete. Or cette route
	// existe justement pour delivrer ce jeton : is_user_logged_in() y renvoie
	// donc toujours faux. On lit nous-memes le cookie de session, ce qui est
	// sans risque : on ne remet un jeton qu'a qui detient deja ces cookies.
	if ( ! is_user_logged_in() ) {
		$user_id = wp_validate_auth_cookie( '', 'logged_in' );
		if ( $user_id ) {
			wp_set_current_user( $user_id );
		}
	}

	$connecte = is_user_logged_in();

	// La liste accompagne le jeton : les pages n'ont ainsi qu'un seul appel a
	// faire au lieu de deux en cascade, ce qui divise l'attente par deux.
	return rest_ensure_response(
		array(
			'connecte' => $connecte,
			'nom'      => $connecte ? wp_get_current_user()->display_name : '',
			'nonce'    => $connecte ? wp_create_nonce( 'wp_rest' ) : '',
			'modeles'  => $connecte ? genitem_models_lire( get_current_user_id() ) : array(),
		)
	);
}

function genitem_models_route_moi() {
	// Meme remarque que pour la route /jeton ci-dessus.
	if ( ! is_user_logged_in() ) {
		$user_id = wp_validate_auth_cookie( '', 'logged_in' );
		if ( $user_id ) {
			wp_set_current_user( $user_id );
		}
	}

	$connecte = is_user_logged_in();
	$utilisateur = $connecte ? wp_get_current_user() : null;

	return rest_ensure_response(
		array(
			'connecte' => $connecte,
			'nom'      => $connecte ? $utilisateur->display_name : '',
		)
	);
}

function genitem_models_route_lire() {
	return rest_ensure_response(
		array(
			'ok'      => true,
			'modeles' => genitem_models_lire( get_current_user_id() ),
		)
	);
}

function genitem_models_route_ecrire( WP_REST_Request $requete ) {
	$corps = $requete->get_json_params();
	$liste = ( is_array( $corps ) && isset( $corps['modeles'] ) ) ? $corps['modeles'] : null;

	$resultat = genitem_models_ecrire( get_current_user_id(), $liste );
	if ( is_wp_error( $resultat ) ) {
		return $resultat;
	}

	return rest_ensure_response(
		array(
			'ok'      => true,
			'modeles' => $resultat,
		)
	);
}

/* -------------------------------------------------------------------------
 * Passerelle vers les pages chargees dans un cadre
 *
 * Les pages Genitem sont des fichiers statiques servis depuis
 * /wp-content/uploads/code/ : WordPress ne peut donc pas y injecter le jeton
 * (nonce) exige pour les ecritures REST. On le depose ici sur la page Divi
 * qui contient le cadre ; comme les deux documents partagent le meme domaine,
 * le contenu du cadre peut le lire via window.parent.
 * ---------------------------------------------------------------------- */

add_action( 'wp_enqueue_scripts', 'genitem_models_exposer_contexte' );

function genitem_models_exposer_contexte() {
	// Script vide : il ne sert qu'a porter les donnees ci-dessous.
	wp_register_script( 'genitem-auth', '', array(), GENITEM_MODELS_VERSION, false );
	wp_enqueue_script( 'genitem-auth' );

	$donnees = array(
		'rest'     => esc_url_raw( rest_url( 'genitem/v1/' ) ),
		'nonce'    => wp_create_nonce( 'wp_rest' ),
		'connecte' => is_user_logged_in(),
		'nom'      => is_user_logged_in() ? wp_get_current_user()->display_name : '',
		'urlLogin' => wp_login_url(),
		'urlLogout'=> wp_logout_url( home_url() ),
	);

	wp_add_inline_script(
		'genitem-auth',
		'window.GenitemAuth = ' . wp_json_encode( $donnees ) . ';',
		'before'
	);
}

/* -------------------------------------------------------------------------
 * Ecran d'administration : consulter les listes enregistrees
 * ---------------------------------------------------------------------- */

/**
 * Icone du menu d'administration.
 *
 * Pour en changer, remplacez la valeur ci-dessous par l'un des noms proposes :
 * robot, cerveau, puce, etincelles, reseau, items, dialogue, genitem.
 * Les icones sont monochromes : WordPress les recolore selon le theme
 * d'administration, les couleurs d'origine seraient donc perdues.
 */
define( 'GENITEM_MODELS_ICONE', 'robot' );

function genitem_models_icone_menu() {
	$icones = array(
		'robot' => 'PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PHJlY3QgeD0iMy41IiB5PSI2IiB3aWR0aD0iMTMiIGhlaWdodD0iMTAuNSIgcng9IjIuNSIgZmlsbD0iYmxhY2siLz48Y2lyY2xlIGN4PSI3LjYiIGN5PSIxMC42IiByPSIxLjYiIGZpbGw9IndoaXRlIi8+PGNpcmNsZSBjeD0iMTIuNCIgY3k9IjEwLjYiIHI9IjEuNiIgZmlsbD0id2hpdGUiLz48cmVjdCB4PSI4IiB5PSIxMy42IiB3aWR0aD0iNCIgaGVpZ2h0PSIxLjIiIHJ4PSIwLjYiIGZpbGw9IndoaXRlIi8+PGxpbmUgeDE9IjEwIiB5MT0iMi42IiB4Mj0iMTAiIHkyPSI1LjgiIHN0cm9rZT0iYmxhY2siIHN0cm9rZS13aWR0aD0iMS40IiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48Y2lyY2xlIGN4PSIxMCIgY3k9IjIuMiIgcj0iMS41IiBmaWxsPSJibGFjayIvPjxyZWN0IHg9IjAuOCIgeT0iOSIgd2lkdGg9IjIuMiIgaGVpZ2h0PSI0LjUiIHJ4PSIxLjEiIGZpbGw9ImJsYWNrIi8+PHJlY3QgeD0iMTciIHk9IjkiIHdpZHRoPSIyLjIiIGhlaWdodD0iNC41IiByeD0iMS4xIiBmaWxsPSJibGFjayIvPjwvc3ZnPg==',
		'cerveau' => 'PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PHBhdGggZD0iTTcuMiAzLjVjLTEuNyAwLTMgMS4yLTMuMiAyLjhDMi44IDYuOCAyIDcuOSAyIDkuMmMwIDAuOSAwLjQgMS43IDEgMi4yLTAuMiAwLjQtMC4zIDAuOC0wLjMgMS4yIDAgMS42IDEuMyAyLjkgMi45IDIuOSAwLjMgMCAwLjYgMCAwLjktMC4xIDAuNSAwLjggMS40IDEuMyAyLjQgMS4zIDAuNCAwIDAuOC0wLjEgMS4xLTAuMlYzLjhDOS40IDMuNiA4LjQgMy41IDcuMiAzLjV6IiBmaWxsPSJibGFjayIvPjxwYXRoIGQ9Ik0xMi44IDMuNWMxLjcgMCAzIDEuMiAzLjIgMi44IDEuMiAwLjUgMiAxLjYgMiAyLjkgMCAwLjktMC40IDEuNy0xIDIuMiAwLjIgMC40IDAuMyAwLjggMC4zIDEuMiAwIDEuNi0xLjMgMi45LTIuOSAyLjktMC4zIDAtMC42IDAtMC45LTAuMS0wLjUgMC44LTEuNCAxLjMtMi40IDEuMy0wLjQgMC0wLjgtMC4xLTEuMS0wLjJWMy44QzEwLjYgMy42IDExLjYgMy41IDEyLjggMy41eiIgZmlsbD0iYmxhY2siLz48bGluZSB4MT0iMTAiIHkxPSI0LjQiIHgyPSIxMCIgeTI9IjE2LjMiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMSIvPjwvc3ZnPg==',
		'puce' => 'PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PHJlY3QgeD0iNS41IiB5PSI1LjUiIHdpZHRoPSI5IiBoZWlnaHQ9IjkiIHJ4PSIxLjYiIGZpbGw9ImJsYWNrIi8+PHJlY3QgeD0iOC4yIiB5PSI4LjIiIHdpZHRoPSIzLjYiIGhlaWdodD0iMy42IiByeD0iMC42IiBmaWxsPSJ3aGl0ZSIvPjxsaW5lIHgxPSI3LjYiIHkxPSIyLjYiIHgyPSI3LjYiIHkyPSI1LjUiIHN0cm9rZT0iYmxhY2siIHN0cm9rZS13aWR0aD0iMS40IiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48bGluZSB4MT0iMTIuNCIgeTE9IjIuNiIgeDI9IjEyLjQiIHkyPSI1LjUiIHN0cm9rZT0iYmxhY2siIHN0cm9rZS13aWR0aD0iMS40IiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48bGluZSB4MT0iNy42IiB5MT0iMTQuNSIgeDI9IjcuNiIgeTI9IjE3LjQiIHN0cm9rZT0iYmxhY2siIHN0cm9rZS13aWR0aD0iMS40IiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48bGluZSB4MT0iMTIuNCIgeTE9IjE0LjUiIHgyPSIxMi40IiB5Mj0iMTcuNCIgc3Ryb2tlPSJibGFjayIgc3Ryb2tlLXdpZHRoPSIxLjQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxsaW5lIHgxPSIyLjYiIHkxPSI3LjYiIHgyPSI1LjUiIHkyPSI3LjYiIHN0cm9rZT0iYmxhY2siIHN0cm9rZS13aWR0aD0iMS40IiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48bGluZSB4MT0iMi42IiB5MT0iMTIuNCIgeDI9IjUuNSIgeTI9IjEyLjQiIHN0cm9rZT0iYmxhY2siIHN0cm9rZS13aWR0aD0iMS40IiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48bGluZSB4MT0iMTQuNSIgeTE9IjcuNiIgeDI9IjE3LjQiIHkyPSI3LjYiIHN0cm9rZT0iYmxhY2siIHN0cm9rZS13aWR0aD0iMS40IiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48bGluZSB4MT0iMTQuNSIgeTE9IjEyLjQiIHgyPSIxNy40IiB5Mj0iMTIuNCIgc3Ryb2tlPSJibGFjayIgc3Ryb2tlLXdpZHRoPSIxLjQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjwvc3ZnPg==',
		'etincelles' => 'PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PHBhdGggZD0iTTcuOCAyLjJsMS42IDQuMyA0LjMgMS42LTQuMyAxLjYtMS42IDQuMy0xLjYtNC4zLTQuMy0xLjYgNC4zLTEuNnoiIGZpbGw9ImJsYWNrIi8+PHBhdGggZD0iTTE0LjYgMTAuNmwwLjkgMi4zIDIuMyAwLjktMi4zIDAuOS0wLjkgMi4zLTAuOS0yLjMtMi4zLTAuOSAyLjMtMC45eiIgZmlsbD0iYmxhY2siLz48L3N2Zz4=',
		'reseau' => 'PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PGNpcmNsZSBjeD0iMy40IiBjeT0iNSIgcj0iMS43IiBmaWxsPSJibGFjayIvPjxjaXJjbGUgY3g9IjMuNCIgY3k9IjE1IiByPSIxLjciIGZpbGw9ImJsYWNrIi8+PGNpcmNsZSBjeD0iMTAiIGN5PSIxMCIgcj0iMS45IiBmaWxsPSJibGFjayIvPjxjaXJjbGUgY3g9IjE2LjYiIGN5PSI0LjQiIHI9IjEuNyIgZmlsbD0iYmxhY2siLz48Y2lyY2xlIGN4PSIxNi42IiBjeT0iMTAiIHI9IjEuNyIgZmlsbD0iYmxhY2siLz48Y2lyY2xlIGN4PSIxNi42IiBjeT0iMTUuNiIgcj0iMS43IiBmaWxsPSJibGFjayIvPjxsaW5lIHgxPSIzLjQiIHkxPSI1IiB4Mj0iMTAiIHkyPSIxMCIgc3Ryb2tlPSJibGFjayIgc3Ryb2tlLXdpZHRoPSIxLjEiLz48bGluZSB4MT0iMy40IiB5MT0iMTUiIHgyPSIxMCIgeTI9IjEwIiBzdHJva2U9ImJsYWNrIiBzdHJva2Utd2lkdGg9IjEuMSIvPjxsaW5lIHgxPSIxMCIgeTE9IjEwIiB4Mj0iMTYuNiIgeTI9IjQuNCIgc3Ryb2tlPSJibGFjayIgc3Ryb2tlLXdpZHRoPSIxLjEiLz48bGluZSB4MT0iMTAiIHkxPSIxMCIgeDI9IjE2LjYiIHkyPSIxMCIgc3Ryb2tlPSJibGFjayIgc3Ryb2tlLXdpZHRoPSIxLjEiLz48bGluZSB4MT0iMTAiIHkxPSIxMCIgeDI9IjE2LjYiIHkyPSIxNS42IiBzdHJva2U9ImJsYWNrIiBzdHJva2Utd2lkdGg9IjEuMSIvPjwvc3ZnPg==',
		'items' => 'PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PGNpcmNsZSBjeD0iNCIgY3k9IjUuMiIgcj0iMS41IiBmaWxsPSJibGFjayIvPjxjaXJjbGUgY3g9IjQiIGN5PSIxMCIgcj0iMS41IiBmaWxsPSJibGFjayIvPjxjaXJjbGUgY3g9IjQiIGN5PSIxNC44IiByPSIxLjUiIGZpbGw9ImJsYWNrIi8+PHJlY3QgeD0iNy41IiB5PSI0LjMiIHdpZHRoPSI5LjUiIGhlaWdodD0iMS44IiByeD0iMC45IiBmaWxsPSJibGFjayIvPjxyZWN0IHg9IjcuNSIgeT0iOS4xIiB3aWR0aD0iOS41IiBoZWlnaHQ9IjEuOCIgcng9IjAuOSIgZmlsbD0iYmxhY2siLz48cmVjdCB4PSI3LjUiIHk9IjEzLjkiIHdpZHRoPSI2LjUiIGhlaWdodD0iMS44IiByeD0iMC45IiBmaWxsPSJibGFjayIvPjwvc3ZnPg==',
		'dialogue' => 'PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PHBhdGggZD0iTTIuNiA0LjJoMTQuOGMwLjkgMCAxLjYgMC43IDEuNiAxLjZ2Ni42YzAgMC45LTAuNyAxLjYtMS42IDEuNkg4LjRsLTMuNiAzdi0zSDIuNmMtMC45IDAtMS42LTAuNy0xLjYtMS42VjUuOGMwLTAuOSAwLjctMS42IDEuNi0xLjZ6IiBmaWxsPSJibGFjayIvPjxjaXJjbGUgY3g9IjYuNCIgY3k9IjkuMSIgcj0iMS4zIiBmaWxsPSJ3aGl0ZSIvPjxjaXJjbGUgY3g9IjEwIiBjeT0iOS4xIiByPSIxLjMiIGZpbGw9IndoaXRlIi8+PGNpcmNsZSBjeD0iMTMuNiIgY3k9IjkuMSIgcj0iMS4zIiBmaWxsPSJ3aGl0ZSIvPjwvc3ZnPg==',
		'genitem' => 'PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PGxpbmUgeDE9IjEwLjAxIiB5MT0iMS41NCIgeDI9IjkuNzgiIHkyPSI1LjE5IiBzdHJva2U9ImJsYWNrIiBzdHJva2Utd2lkdGg9IjEuNSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PGxpbmUgeDE9IjEwLjAxIiB5MT0iMS4wMCIgeDI9IjQuNzYiIHkyPSI2LjIzIiBzdHJva2U9ImJsYWNrIiBzdHJva2Utd2lkdGg9IjEuNSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PGxpbmUgeDE9IjEwLjAxIiB5MT0iMS4wMCIgeDI9IjE1LjAyIiB5Mj0iNS42NiIgc3Ryb2tlPSJibGFjayIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxsaW5lIHgxPSI4LjQwIiB5MT0iMTMuOTgiIHgyPSIxMC4zNSIgeTI9IjE4LjY0IiBzdHJva2U9ImJsYWNrIiBzdHJva2Utd2lkdGg9IjEuNSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PGxpbmUgeDE9IjEwLjAxIiB5MT0iOC40NSIgeDI9IjguNDMiIHkyPSIxMy4zMCIgc3Ryb2tlPSJibGFjayIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxjaXJjbGUgY3g9IjEwLjAxIiBjeT0iMS4wMCIgcj0iMS40MCIgZmlsbD0iYmxhY2siLz48Y2lyY2xlIGN4PSI1LjE5IiBjeT0iNS45NiIgcj0iMS40MCIgZmlsbD0iYmxhY2siLz48Y2lyY2xlIGN4PSI5LjYyIiBjeT0iNy4xNiIgcj0iMS40MCIgZmlsbD0iYmxhY2siLz48Y2lyY2xlIGN4PSIxNS4yNCIgY3k9IjYuMjMiIHI9IjEuNDAiIGZpbGw9ImJsYWNrIi8+PGNpcmNsZSBjeD0iOC40MyIgY3k9IjEzLjg0IiByPSIxLjQwIiBmaWxsPSJibGFjayIvPjxjaXJjbGUgY3g9IjEwLjcxIiBjeT0iMTkuMDAiIHI9IjEuNDAiIGZpbGw9ImJsYWNrIi8+PC9zdmc+'
	);

	$choix = defined( 'GENITEM_MODELS_ICONE' ) ? GENITEM_MODELS_ICONE : 'robot';
	if ( ! isset( $icones[ $choix ] ) ) {
		$choix = 'robot';
	}

	return 'data:image/svg+xml;base64,' . $icones[ $choix ];
}

add_action( 'admin_menu', 'genitem_models_menu_admin' );

function genitem_models_menu_admin() {
	add_menu_page(
		__( 'Modèles Genitem', 'genitem-models' ),
		__( 'Modèles Genitem', 'genitem-models' ),
		'manage_options',
		'genitem-models',
		'genitem_models_page_admin',
		genitem_models_icone_menu(),
		81
	);
}

function genitem_models_page_admin() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$utilisateurs = get_users(
		array(
			'meta_key' => GENITEM_MODELS_META_KEY,
			'fields'   => array( 'ID', 'display_name', 'user_email' ),
		)
	);

	echo '<div class="wrap">';
	echo '<h1>' . esc_html__( 'Modèles Genitem', 'genitem-models' ) . '</h1>';
	echo '<p>' . esc_html__( 'Liste des modèles enregistrée par chaque utilisateur connecté.', 'genitem-models' ) . '</p>';

	if ( empty( $utilisateurs ) ) {
		echo '<p><em>' . esc_html__( 'Aucun utilisateur n\'a encore enregistré de modèles.', 'genitem-models' ) . '</em></p>';
		echo '</div>';
		return;
	}

	echo '<table class="widefat striped"><thead><tr>';
	echo '<th>' . esc_html__( 'Utilisateur', 'genitem-models' ) . '</th>';
	echo '<th>' . esc_html__( 'Adresse e-mail', 'genitem-models' ) . '</th>';
	echo '<th>' . esc_html__( 'Modèles', 'genitem-models' ) . '</th>';
	echo '</tr></thead><tbody>';

	foreach ( $utilisateurs as $u ) {
		$liste = genitem_models_lire( $u->ID );
		echo '<tr>';
		echo '<td>' . esc_html( $u->display_name ) . '</td>';
		echo '<td>' . esc_html( $u->user_email ) . '</td>';
		echo '<td><code>' . esc_html( implode( ', ', $liste ) ) . '</code></td>';
		echo '</tr>';
	}

	echo '</tbody></table></div>';
}

/* -------------------------------------------------------------------------
 * Espace d'administration reserve
 *
 * Les comptes sans droit de publication (abonnes) n'ont rien a faire dans le
 * tableau de bord : ils sont renvoyes vers le site. Les administrateurs, les
 * editeurs et les auteurs gardent un acces complet.
 * ---------------------------------------------------------------------- */

/**
 * Vrai pour les comptes qui doivent rester sur le site public.
 * Le droit "edit_posts" sert de repere : les abonnes ne l'ont pas, tous les
 * roles qui travaillent dans le tableau de bord l'ont.
 */
function genitem_models_acces_restreint() {
	if ( ! is_user_logged_in() ) {
		return false;
	}
	/**
	 * Permet de changer la regle sans modifier le plugin, par exemple pour
	 * restreindre aussi un role maison.
	 */
	return (bool) apply_filters( 'genitem_models_acces_restreint', ! current_user_can( 'edit_posts' ) );
}

/**
 * Renvoie vers l'accueil toute tentative d'ouvrir /wp-admin/.
 * admin-ajax.php et admin-post.php restent accessibles : de nombreux plugins
 * et le theme s'en servent pour des requetes de fond, y compris cote public.
 */
add_action( 'admin_init', 'genitem_models_bloquer_admin' );

function genitem_models_bloquer_admin() {
	if ( wp_doing_ajax() ) {
		return;
	}
	if ( defined( 'DOING_CRON' ) && DOING_CRON ) {
		return;
	}
	$fichier = isset( $_SERVER['PHP_SELF'] ) ? basename( sanitize_text_field( wp_unslash( $_SERVER['PHP_SELF'] ) ) ) : '';
	if ( in_array( $fichier, array( 'admin-ajax.php', 'admin-post.php' ), true ) ) {
		return;
	}

	if ( genitem_models_acces_restreint() ) {
		wp_safe_redirect( home_url() );
		exit;
	}
}

/**
 * Retire la barre noire d'administration en haut du site.
 */
add_filter( 'show_admin_bar', 'genitem_models_masquer_barre' );

function genitem_models_masquer_barre( $afficher ) {
	return genitem_models_acces_restreint() ? false : $afficher;
}

/**
 * Apres connexion, un abonne arrive sur le site et non sur le tableau de bord.
 */
add_filter( 'login_redirect', 'genitem_models_redirection_connexion', 10, 3 );

function genitem_models_redirection_connexion( $url, $demandee, $utilisateur ) {
	if ( ! ( $utilisateur instanceof WP_User ) ) {
		return $url;
	}
	if ( user_can( $utilisateur, 'edit_posts' ) ) {
		return $url;
	}
	return home_url();
}
